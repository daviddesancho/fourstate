=======
FourState
=======

This is a simple class to explore the dynamics in a kinetic network involving
4 states with 2 intermediates.

Contributors
============
This code has been written by David De Sancho.

Installation
============

  python setup.py install --user
